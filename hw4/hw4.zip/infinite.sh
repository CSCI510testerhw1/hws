#!/bin/bash
while :
do
    sleep 0   
done &
